const {app,BrowserWindow} = require('electron')

function createWindow()
{
    const win=new BrowserWindow({
        width:700,
        height:600
    })
    win.loadFile('Tic.html')
    win.setMenu(null);
}

app.whenReady().then(createWindow)